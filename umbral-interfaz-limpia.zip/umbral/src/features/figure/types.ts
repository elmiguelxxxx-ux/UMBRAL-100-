export interface UmbralFigureProps {}
